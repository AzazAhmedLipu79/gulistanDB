from setuptools import setup

setup(
    name='gulistandb',
    version='0.0.1',
    install_requires=[
        'pandas',
        # add more dependencies as needed
    ],
    package_dir={'': 'src'},

    # metadata
    author='Azaz Ahmed',
    author_email='lipuahmedazaz79@gmail.com',
    description='Short project description',
    license='MIT'
)
